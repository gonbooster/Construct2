/////////////////////////////////////////////

var array_Datos = [], count = 0;
var io = require("socket.io").listen(8099);

var Puerto = 8099;
var fecha = new Date();
var PJ_X = 0;
var PJ_Y = 0;
var PJ_Angle = 0;

io.set('log level', 1);
console.log("########## SERVIDOR INICIALIZADO ##########");
console.log(fecha);
console.log("Puerto: " + Puerto);

io.sockets.on("connection", function(socket) {

	////// MENSAJE INICIAL --Solo se realiza al realizar la conexión entre cliente y servidor--/////

	var cliente_UID = count++;
	//UID del Cliente

	console.log('Jugador_UID: ' + cliente_UID + ' conectado...');

	var datos = array_Datos[cliente_UID] = [cliente_UID, PJ_X, PJ_Y, PJ_Angle];

	//COMANDO "I" --> Envia la posición inicial y la UID del JUGADOR	
	datos[1] = Math.random() * 500;
	datos[2] = Math.random() * 500;
	datos[3] = Math.random() * 500;
	console.log('[I] --> Jugador_UID: ' + datos[0] + ' - X: ' + datos[1] + ' - Y: ' + datos[2] + ' - Angulo: ' + datos[3]);
	socket.send('I,' + datos[0] + ',' + datos[1] + ',' + datos[2] + ',' + datos[3]);

	//COMANDO "C" --> Envia al cliente conectado la posición de los demás jugadores
	for (var cliente_ID = 0; cliente_ID < array_Datos.length; cliente_ID++)
	{
		if (cliente_ID != cliente_UID)
		{
			entity = array_Datos[cliente_ID];
			//Seleccionamos los datos del cliente cliente_ID   -----   cliente_ID != cliente_UID
			if ( typeof (entity) != "undefined" && entity != null)
			{
				console.log('[C] --> Enviamos la posición del Jugador_UID: ' + cliente_UID + ' al Jugador_UID: ' + cliente_ID);
				//console.log('[C] --> Jugador_UID: '+ entity[0] + ' - X: ' + entity[1] + ' - Y: ' + entity[2]);
				socket.send('C,' + entity[0] + ',' + entity[1] + ',' + entity[2] + ',' + entity[3]);
			}
		}
	}

	//COMANDO "C" --> Crea tu pj en los demás clientes
	//console.log('[C] BROADCAST --> Jugador_UID: '+ datos[0] + ' - X: ' + datos[1] + ' - Y: ' + datos[2] + ' - Angulo: ' + datos[3]);
	socket.broadcast.emit("message", 'C,' + datos[0] + ',' + datos[1] + ',' + datos[2] + ',' + datos[3]);

	////// FIN MENSAJE INICIAL/////

	socket.on("message", function(data) {

		//console.log(cliente_UID + ' sent: ' +data);
		var nuevo_dato = data.split(',');

		//COMANDO "A" --> Actualizamos la posición de los PJS de todos los demás jugadores
		if (nuevo_dato[0] == 'A') {
			datos[1] = nuevo_dato[1];
			//X
			datos[2] = nuevo_dato[2];
			//y
			datos[3] = nuevo_dato[3];
			//Angulo
			datos[4] = nuevo_dato[4];
			//Velocidad X
			datos[5] = nuevo_dato[5];
			//Velocidad Y

			//console.log('[A] BROADCAST --> Jugador_UID: '+ datos[0] + ' - X: ' + datos[1] + ' - Y: ' + datos[2] + ' - Angulo: ' + datos[3]);
			socket.broadcast.emit("message", 'A,' + datos[0] + ',' + datos[1] + ',' + datos[2] + ',' + datos[3]);

			//COMANDO "S" --> Actualizamos la posición de las balas de todos los demás jugadores
		} else if (nuevo_dato[0] == 'S') {
			var bala_datos = [];
			bala_datos[0] = nuevo_dato[1];
			//x
			bala_datos[1] = nuevo_dato[2];
			//y
			bala_datos[2] = nuevo_dato[3];
			//Angulo

			//console.log('[S] BROADCAST --> Jugador_UID: '+ datos[0] + ' - X: ' + bala_datos[0] + ' - Y: ' + bala_datos[1]);
			socket.broadcast.emit("message", 'S,' + datos[0] + ',' + bala_datos[0] + ',' + bala_datos[1] + ',' + bala_datos[2]);
		
		//COMANDO "D" --> Elimina los datos del jugador cliente_UID
		} else if (nuevo_dato[0] == 'D') {
			array_Datos[cliente_UID]=null;
			//Eliminamos los datos de el cliente_UID para que no se generen pjs de más al conectarse nuevos clientes
			console.log('[D] Elimando futuros pjs de más --> Jugador_UID: ' + datos[0]);
		}
	});

	//DESCONEXION
	socket.on('disconnect', function() {

		console.log('Jugador_UID: ' + cliente_UID + ' desconectado...');

		//COMANDO "D" --> Eliminamos los Pjs de los jugadores desconectados
		
		array_Datos[cliente_UID]=null;
		//Eliminamos los datos de el cliente_UID para que no se generen pjs de más al conectarse nuevos clientes
		console.log('[D] BROADCAST --> Jugador_UID: ' + datos[0]);
		socket.broadcast.emit("message", 'D,' + datos[0]);

	});
});

