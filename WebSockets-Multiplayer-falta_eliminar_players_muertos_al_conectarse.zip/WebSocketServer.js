/////////////////////////////////////////////

var entities = [], count = 7;
var ws = require("nodejs-websocket");
var Puerto = 8099;
var fecha = new Date();
var INITIAL_X = Math.random() * 500;//Return a random number between 1 and x;
var INITIAL_Y = Math.random() * 500;//Return a random number between 1 and x;
var INITIAL_ANGLE = Math.random() * 500;//Return a random number between 1 and x;
var INITIAL_VEL_X = 0;
var INITIAL_VEL_Y = 0;
console.log("########## SERVIDOR INICIALIZADO ##########");
console.log(fecha);
console.log("Puerto: " + Puerto);

var server = ws.createServer("connection", function(socket) {
	
	console.log('Nueva conexión...');
	
////// MENSAJE INICIAL --Solo se realiza al realizar la conexión entre cliente y servidor--/////

	var myNumber = count++;// Numero de Usuario y Total de usuarios
	
	var JsonArray = [];
	var new_data= [];
	var mySelf = entities[myNumber] = [myNumber, INITIAL_X, INITIAL_Y, INITIAL_ANGLE, INITIAL_VEL_X, INITIAL_VEL_Y];
	
	//COMANDO "I" --> Envia la posición inicial y la UID del JUGADOR 
		 JsonArray = JSON.stringify({
		"c2array" : true,
		"size" : [4, 1, 1],
		"data" : [[["I"]], [[mySelf[0]]], [[mySelf[1]]], [[mySelf[2]]]]
	});// array JSON	
	//console.log('[I] Nueva conexion --> Jugador_UID: '+ mySelf[0] + ' - X: ' + mySelf[1] + ' - Y: ' + mySelf[2]);
	console.log('[I] --> ' + JsonArray);
	socket.sendText(JsonArray); //enviamos el socket

	//COMANDO "C" --> Envia al cliente conectado la posición de los demás jugadores
	for (var entity_idx = 0; entity_idx < entities.length; entity_idx++) {//send initial update
		if (entity_idx != myNumber) {
			entity = entities[entity_idx];
			if ( typeof (entity) != "undefined" && entity != null) {
				JsonArray = JSON.stringify({
					"c2array" : true,
					"size" : [4, 1, 1],
					"data" : [[["C"]], [[entity[0]]], entity[1], entity[2]]
				});// array JSON
				//console.log('[C] --> Jugador_UID: '+ entity[0] + ' - X: ' + entity[1] + ' - Y: ' + entity[2]);
				console.log('[C] --> ' + JsonArray);
				socket.sendText(JsonArray);		
			}
		}
	}
	//COMANDO "C" --> Crea una nueva entidad en todos los demás jugadores
	JsonArray = JSON.stringify({
		"c2array" : true,
		"size" : [5, 1, 1],
		"data" : [[["C"]], [[mySelf[0]]], [[mySelf[1]]], [[mySelf[2]]], [[mySelf[3]]]]
	});// array JSON
	//console.log('[C] BROADCAST --> Jugador_UID: '+ mySelf[0] + ' - X: ' + mySelf[1] + ' - Y: ' + mySelf[2]);
	console.log('[C] BROADCAST --> ' + JsonArray);
	broadcast(server, JsonArray);


////// FIN MENSAJE INICIAL/////

	socket.on("text", function (data) {
		
		//console.log(data);
		new_data = JSON.parse(data);
		
        //COMANDO "A" --> Actualizamos la posición de los PJS de todos los demás jugadores
        if (new_data.data[0] == 0) { // 0 == A
            mySelf[1] = new_data.data[1];
            mySelf[2] = new_data.data[2];
            mySelf[3] = new_data.data[3];
            mySelf[4] = new_data.data[4];
            
           JsonArray = JSON.stringify({
				"c2array" : true,
				"size" : [6, 1, 1],
				"data" : [[["A"]], [[mySelf[0]]], mySelf[1], mySelf[2], mySelf[3], mySelf[4]]
			});// array JSON
			//console.log('[A] BROADCAST --> Jugador_UID: '+ mySelf[0] + ' - X: ' + mySelf[1] + ' - Y: ' + mySelf[2]);
			//console.log('[A] BROADCAST--> ' + JsonArray);
			broadcast(server, JsonArray);
        }
        
        //COMANDO "S" --> Actualizamos la posición de las balas de todos los demás jugadores
        else if (new_data.data[0] == '1') { // 1 == S
           var shoot_info = [];
            shoot_info[0] = new_data.data[1]; //ini x
            shoot_info[1] = new_data.data[2]; //ini y
            shoot_info[2] = new_data.data[3]; //degrees

            JsonArray = JSON.stringify({
				"c2array" : true,
				"size" : [5, 1, 1],
				"data" : [[["S"]], [[mySelf[0]]], shoot_info[0], shoot_info[1], shoot_info[2]]
			});// array JSON
			//console.log('[S] BROADCAST --> Jugador_UID: '+ mySelf[0] + ' - X: ' + shoot_info[0] + ' - Y: ' + shoot_info[1]);
			//console.log('[S] BROADCAST--> ' + JsonArray);
			broadcast(server, JsonArray);
        }
     /*
      	//COMANDO "D" --> Eliminamos el jugador dado
        else if (new_data.data[0] == '2') { // 2 == D
        	
            JsonArray = JSON.stringify({
				"c2array" : true,
				"size" : [2, 1, 1],
				"data" : [[["D"]], [[mySelf[0]]]]
			});// array JSON
			console.log('[D] BROADCAST --> Jugador_UID: '+ mySelf[0]);
			//console.log('[D] BROADCAST--> ' + JsonArray);
			//Update all the other clients about my update
			broadcast(server, JsonArray);
        }
        */
    });
	
	//SURGUE CUANDO UN CLIENTE SE DESCONECTA del servidor
	//COMANDO "D" --> Elimina el Pjd el jugador desconectado
	socket.on("close", function(code, reason) {//Cierre de la aplicacion
		console.log('Conexion cerrada...');
			JsonArray = JSON.stringify({
				"c2array" : true,
				"size" : [2, 1, 1],
				"data" : [[["D"]],[[mySelf[0]]]]
			});// array JSON
			//console.log('[D] Conexion cerrada --> Jugador_UID: '+ mySelf[0]);
			console.log('[D] BROADCAST --> ' + JsonArray);			
			//Update all the other clients about my update
			broadcast(server, JsonArray);
	});
	
}).listen(Puerto);

// BROADCAST --> Enviar un mensaje a todos los clientess
function broadcast(server, msg) {
	server.connections.forEach(function(conn) {
		conn.sendText(msg)
	})
}
